# file should be called synonyms.py
'''Semantic Similarity: starter code
Author: Michael Guerzhoy. Last modified: Nov. 14, 2016.
'''
import math

def norm(vec):
    '''Return the norm of a vector stored as a dictionary,
    as described in the handout for Project 3.
    '''
    
    sum_of_squares = 0.0  
    for x in vec:
        sum_of_squares += vec[x] * vec[x]
    
    return math.sqrt(sum_of_squares)

#problem 1 
def cosine_similarity(vec1, vec2):
  '''return the cosine similarity between the sparce vectors vec1 and vec 2, which are stored as a dictionary'''
  # finished, also tested with discord code and passed
  #bet, thanks 
  num = 0
  denom = 0
  denom1 = 0
  denom2 = 0
  cos_sim = 0

  if len(vec1) <= len(vec2):
    # compare keys in vec1 to vec 2
    for words in vec1:
      if words in vec2:
        num = num + vec1[words]*vec2[words]
      else:
        continue
  else:
    # compare keys in vec2 to vec 1
    for words in vec2:
      if words in vec1:
        num = num + vec2[words]*vec1[words]
      else:
        continue

  for words in vec1:
    denom1 = denom1 + ((vec1[words])**2)
  for words in vec2:
    denom2 = denom2 + ((vec2[words])**2)

  denom = (denom1*denom2)**0.5
  cos_sim = num/denom
  
  return cos_sim

#problem 2 
def build_semantic_descriptors(sentences):
  '''return a dictionary d such that for every word w that appears in at least one of the sentences, d[w] represents the semantic descriptor of w'''
  #HINT: think of a way to update the semantic descriptor dictionary sentence-by-sentence.
  
  res = {} # final dictionary result
  no_dup = []

  for i in range (len(sentences)):
    no_dup.append(list(set(sentences[i]))) # get rid of duplicates
    for w in no_dup[i]:
      if w not in res:
        res[w] = {}
  

  for i in range (len(no_dup)): # go through all sentences
    for w in no_dup[i]: # go through the words in the sentence
      for j in range (len(no_dup[i])):
        if no_dup[i][j] != w: # if the word does not equal the word in res that we are looking at
            
          if no_dup[i][j] not in res[w]:
            res[w][no_dup[i][j]] = 1
              
          else:
            res[w][no_dup[i][j]] += 1
              
  return res

#problem 3 
def build_semantic_descriptors_from_files(filenames):
  '''return dictionary of the semantic descriptors of all words in the files filenames'''
  full_text =[]
  for i in range (0, len(filenames)):
    text = open(filenames[i], "r", encoding="latin1")
    words = text.read()
    words = words.lower() #making it all lower case 
    #replace all sentence ending punucation with a period 
    words = words.replace("!", ".") #assuming that each puncuation ends with a space after 
    words = words.replace("?", ".")  
   
    #replacing the 
    words = words.replace("--", ";")
    words = words.replace("-", ";")
    words = words.replace(",", ";")
    words = words.replace("--", ";")
    words = words.replace(":", ";")
    words = words.replace(" ; ", ";") 
    words = words.replace(" ;", ";")
    words = words.replace("; ", ";")
    words = words.replace(";", " ") 
    words = words.replace(" . ", ". ")
    words = words.replace(" .", ".")
    words = words.replace("\n", "")
    words = words.replace("\s", "") 
    words = words.replace("  ", " ")
    
    #testing to see if it splits both sentences and words 
    words = words.split(". ")
    for i in range (len(words)): #turning the sentences into list of strings 
      string = words[i] 
      if string == "":
        pass
      else: 
        string = string.split(" ")
        full_text.append(string) 

  #return(full_text)
  return build_semantic_descriptors(full_text)


#problem 4 
def most_similar_word(word, choices, semantic_descriptors, similarity_fn):
  '''return the element of choices which has the largest semantic similarity to word'''
  #from what i understand of build_semantic_descrip. it should return a dictionary with the keys as words and values as the vector of the word 
  #can we assume for this one that the choices are all keys in semantic_descrip ? 

  #also for this function, the higher the float, the higher the similarty correct? 
  #descrip = build_semantic_descriptors(semantic_descriptors)
  res = 0
  maxi = 0 
  largest = None 
  for i in range (len(choices)):
    if word not in semantic_descriptors or choices[i] not in semantic_descriptors:
      return -1 
    else:
      descrip = (semantic_descriptors)
      vec1 = descrip[word]
      vec2 = descrip[choices[i]]
      res = similarity_fn(vec1, vec2) 
      if res > maxi:  
        maxi = res 
        largest = choices[i]
  return largest



def run_similarity_test(filename, semantic_descriptors, similarity_fn):
  '''return the percentage of questions on which most_similar_word() guesses the answer correctly'''

  f = open(filename, encoding = "latin1")
  text = f.read()
  word_list = text.split("\n") # split sentence at every line
  
  res = []
  new_res = []

  answer = ""
  fn_answer = ""
  word = ""
  choices = []
  count = 0
  correct = 0.0

  # go through each sentence and add to res
  for i in range (0, len(word_list)):
    res.append([word_list[i]])

  for i in range (len(word_list)):
    words = word_list[i].split(" ")
    new_res.append(words)

  for elem in new_res:
    if elem == [""]:
      new_res.remove(elem)
      
  for i in range (len(new_res)):
    for j in range (2, len(new_res[i])):
      word = new_res[i][0]
      answer = new_res[i][1]
      choices.append(new_res[i][j])

    fn_answer = most_similar_word(word, choices, semantic_descriptors, similarity_fn)

    if fn_answer == answer:
      count += 1
    else:
      count = count
      
  correct = (count/len(res))*100

  return correct

if __name__ == '__main__':

  #vec1 = {"i":3, "am":3, "a":2, "sick":1, "spiteful":1, "an":1, "unattractive":1}
  #vec2 = {"i":1, "believe":1, "my":1, "is":1, "diseased":1}

  #vec1 = {"a":1, "b":2, "c":3}
  #vec2 = {"b":4, "c":5, "d":6}


  #cosine_similarity(vec1, vec2)

  sentences = [["i", "am", "a", "sick", "man"], ["i", "am", "a", "spiteful", "man"], ["i", "am", "an", "unattractive", "man"], ["i", "believe", "my", "liver", "is", "diseased"], ["however", "i", "know", "nothing", "at", "all", "about", "my", "disease", "and", "do", "not", "know", "for", "certain", "what", "ails", "me"]]

  #sentences = [["because", "work", "orientation", "interest", "aid", "interest", "work",  "interest"], ["GUY", "tree", "refuse", "guy", "guy", "TREE"], ["NATURALLY", "plate", "ultimate", "district", "cultural", "aid", "distric", "refuse", "cultural"]] 

  print(build_semantic_descriptors(sentences))
  #filenames = ["test.txt"]

  
  #filenames = ["between.txt"]
  #print(build_semantic_descriptors_from_files(filenames))

  #build_semantic_descriptors(sentences)
  #print(new_res)

  ###### running code in function 
  #sem_descriptors = build_semantic_descriptors_from_files(["wp.txt", "sw.txt"])
  #res = run_similarity_test("test.txt", sem_descriptors, cosine_similarity)
  #print(res, "of the guesses were correct")


  