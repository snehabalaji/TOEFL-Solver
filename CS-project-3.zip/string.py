f = open("test.txt", encoding = "latin1")
text = f.read()
word_list = text.split("\n") # split sentence at every line
print(word_list)

res = []
for i in range in (len(word_list)):
  print(len(word_list))
  #print(word_list[i])
  #res.append(word_list[elem].split(" "))

#print(res)